---
name: Regal Heritage & Haute Bijoux
colors:
  surface: '#fbf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#fbf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e4e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#4f4539'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#817568'
  outline-variant: '#d2c4b4'
  surface-tint: '#7b581f'
  primary: '#7b581f'
  on-primary: '#ffffff'
  primary-container: '#c59a5b'
  on-primary-container: '#4e3200'
  inverse-primary: '#edbf7c'
  secondary: '#695c54'
  on-secondary: '#ffffff'
  secondary-container: '#efdcd2'
  on-secondary-container: '#6d6058'
  tertiary: '#a83541'
  on-tertiary: '#ffffff'
  tertiary-container: '#ff767f'
  on-tertiary-container: '#73091e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffddb1'
  primary-fixed-dim: '#edbf7c'
  on-primary-fixed: '#291800'
  on-primary-fixed-variant: '#604108'
  secondary-fixed: '#f1dfd5'
  secondary-fixed-dim: '#d5c3b9'
  on-secondary-fixed: '#231a13'
  on-secondary-fixed-variant: '#50443d'
  tertiary-fixed: '#ffdada'
  tertiary-fixed-dim: '#ffb3b4'
  on-tertiary-fixed: '#40000b'
  on-tertiary-fixed-variant: '#881c2b'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 58px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '500'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies the heirloom majesty, artisanal grandeur, and spiritual sanctity of classical temple craftsmanship translated for modern connoisseurs. It balances royal heritage with modern editorial refinement. The emotional atmosphere is prestigious, reverent, and deeply tactile—evoking the sensory presence of antique hand-beaten gold, sanctum warm amber light, and fine woven silks.

The visual style unites **Editorial Luxury Minimalism** with **Tactile Heritage Accents**. Surfaces mimic fine handmade ecru paper and matte brass packaging, paired with rich espresso foundations and deep ruby accents. Grid structures are disciplined and gallery-proportioned, allowing high-detail jewellery photography to breathe without interface clutter.

## Colors

The palette is anchored by four intentional tones drawn from South Indian temple craft and classical jewellery ateliers:

- **Primary (`#c59a5b` - Warm Antique Gold):** Used for focal metallic highlights, active state badges, delicate keyline framing, and primary action embellishments.
- **Secondary (`#1f1610` - Deep Espresso Brown):** Acts as the foundational dark neutral, providing high-contrast editorial typography, solid buttons, and rich header treatments. Supported by `#2a1e17` for subtle elevated dark surfaces.
- **Tertiary (`#7b1123` - Royal Temple Crimson):** Inspired by ruby kemp stones and bridal vermillion. Applied selectively to callouts, "Rent" distinction tags, reservation indicators, and high-priority action alerts.
- **Neutral (`#fcfaf7` - Warm Champagne Cream):** The primary canvas hue, providing warmth and softness superior to sterile white. Supported by `#f7f3ee` for card containers, dividers, and background wells.

## Typography

The type system pairs the aristocratic gravitas of **Playfair Display** with the clean legibility of **Plus Jakarta Sans**. 

- **Display & Headlines:** Set in Playfair Display with medium and semi-bold weights. All-caps treatments on category titles and subtitles must employ tracking (`+0.08em` to `+0.15em`) with thin hairline divider ornaments.
- **Body & Numerical Specs:** Set in Plus Jakarta Sans to ensure gold weights, purity carats, karat values, and rental tenure parameters remain crisp, clear, and scannable.
- **Labels & Micro-copy:** Always rendered in small-caps or uppercase with wide tracking to maintain an archival atelier feel.

## Layout & Spacing

The layout philosophy follows a **Disciplined Fluid Grid** with generous white space evoking museum collection displays.

- **Desktop (12 Columns):** 3rem outer margins with 1.5rem gutters. Product listings utilize 3-column or 4-column balanced modules. Hero showcases and split-panel "Rent vs. Own" decision modules utilize 6-column symmetrical halves.
- **Tablet (8 Columns):** 2rem outer margins and 1rem gutters with 2-column product galleries.
- **Mobile (4 Columns):** 1.25rem outer margins and 1rem gutters. Feature cards collapse into single vertical spans or horizontal swipe carousels with visible overflow indicators.
- **Vertical Rhythm:** Generous vertical spacing (`space-xl` and above) between collection groups ensures that intricate temple jewellery pieces never visually crowd each other.

## Elevation & Depth

Visual hierarchy uses **Tonal Layering with Antique Metallic Borders** rather than aggressive dark drop shadows.

- **Surface Levels:** 
  - Base canvas sits on `#fcfaf7`.
  - Elevated product trays and dialogs sit on `#f7f3ee` or `#ffffff` with a warm gold-tinted hairline border (`1px solid rgba(197, 154, 91, 0.3)`).
  - Floating sticky bars and overlays use soft cream glassmorphism with `backdrop-filter: blur(12px)` and an internal `inset 0 1px 0 rgba(255,255,255,0.8)` reflection.
- **Shadow Profile:** Shadows are diffused, warm-tinted ambient glows:
  - Low Elevation (Cards): `0 4px 20px -2px rgba(31, 22, 16, 0.05), 0 0 1px rgba(197, 154, 91, 0.2)`
  - High Elevation (Drawers, Modals): `0 16px 40px -4px rgba(31, 22, 16, 0.12), 0 0 0 1px rgba(197, 154, 91, 0.25)`

## Shapes

The shape system adopts a **Soft, Sculpted Architectural Profile** (`roundedness: 1`).

- Radius values are purposefully conservative: 4px default for interactive buttons and inputs, and 8px for image containers and modal dialogs.
- Avoid spherical or overly rounded pill shapes; crisp rectangular elegance honors the precision geometry of hand-carved heritage goldsmithing and royal architectural architraves.

## Components

### Dual Action "Rent & Own" Selectors
- **Own (Buy) CTA:** Deep Espresso (`#1f1610`) solid surface with Antique Gold text (`#c59a5b`), crisp 4px border radius, accompanied by an understated `1px solid #c59a5b` outer rim. On hover, background shifts subtly to `#2a1e17` with enhanced warm glow.
- **Rent CTA:** Translucent warm cream fill with a crisp Crimson border (`1px solid #7b1123`), deep crimson typography, accompanied by a small calendar lockup icon. Communicates flexibility and boutique access.

### Jewellery Display Cards
- High-aspect ratio (3:4 portrait) framing with subtle 1px border (`rgba(197, 154, 91, 0.25)`).
- Visual badges for "22K Antique Temple Gold", "Bridal Set", or "Heritage Heirloom" anchored at the top-left using uppercase tracking on an off-white pill tag with a micro gold dot.
- Quick-toggle switcher at the base of the card previewing both the outright retail purchase price and the 3-day / 7-day bridal rental estimate.

### Product Detail & Purity Spec Lists
- Key-value attributes (Gross Weight, Karatage, Gemstone Inlay, Temple Artisan Origin) separated by delicate hairline rules (`rgba(31, 22, 16, 0.08)`).
- Left-aligned labels in uppercase muted brown (`#7a6d64`), right-aligned bold values in deep espresso (`#1f1610`).

### Chips & Filter Pills
- Rectangular with 4px softly rounded corners. Unselected state: bare outline (`1px solid rgba(31, 22, 16, 0.15)`) over transparent fill. Active state: `#1f1610` fill with gold text and gold border.

### Input Fields & Booking Selectors
- Light cream surface (`#f7f3ee`) with bottom-bordered or clean 4px perimeter border in light gold. Floating labels shift upward into small-caps gold text on focus.